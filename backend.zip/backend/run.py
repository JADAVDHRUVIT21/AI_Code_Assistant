from app import create_app

app = create_app()

print("=== RUN.PY EXECUTED ===")
print("App object:", app)
print(app.url_map)

@app.route("/")
def home():
    return "HOME WORKING"

@app.route("/hello")
def hello():
    return "HELLO WORLD"

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)